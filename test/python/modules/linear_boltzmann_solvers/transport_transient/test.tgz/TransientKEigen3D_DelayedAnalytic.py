#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
3D delayed transient k-eigen with semi-analytic 1-precursor point-kinetics response.
Homogeneous infinite-medium (reflecting BCs), 1-group.
"""

import math
import os


def xs_path(name):
    return os.path.join(os.path.dirname(__file__), name)


def build_mesh_3d(n, length):
    dx = length / n
    nodes = [i * dx for i in range(n + 1)]
    meshgen = OrthogonalMeshGenerator(node_sets=[nodes, nodes, nodes])
    grid = meshgen.Execute()
    grid.SetUniformBlockID(0)
    return grid


def delayed_phi_ratio(t, beta, lam, rho, Lambda):
    # Point-kinetics 1-precursor step solution with phi(0)=1, C(0)=beta/(Lambda*lam)
    a = (rho - beta) / Lambda - lam
    b = math.sqrt(((rho - beta) / Lambda + lam) ** 2 + 4.0 * beta * lam / Lambda)
    w1 = 0.5 * (a + b)
    w2 = 0.5 * (a - b)

    # C = (beta/Lambda)/(w+lam) * phi for each mode
    k1 = (beta / Lambda) / (w1 + lam)
    k2 = (beta / Lambda) / (w2 + lam)

    # Solve for coefficients c1, c2 from phi(0)=1 and C(0)=beta/(Lambda*lam)
    c2 = (beta / (Lambda * lam) - k1) / (k2 - k1)
    c1 = 1.0 - c2

    return c1 * math.exp(w1 * t) + c2 * math.exp(w2 * t)


if __name__ == "__main__":
    grid = build_mesh_3d(n=4, length=8.0)

    xs_crit = MultiGroupXS()
    xs_crit.LoadFromOpenSn(xs_path("xs1g_delayed_crit_1p.cxs"))

    xs_super = MultiGroupXS()
    xs_super.LoadFromOpenSn(xs_path("xs1g_delayed_super_1p.cxs"))

    pquad = GLCProductQuadrature3DXYZ(n_polar=2, n_azimuthal=4, scattering_order=0)

    num_groups = 1
    phys = DiscreteOrdinatesProblem(
        mesh=grid,
        num_groups=num_groups,
        groupsets=[
            {
                "groups_from_to": (0, num_groups - 1),
                "angular_quadrature": pquad,
                "inner_linear_method": "classic_richardson",
                "l_abs_tol": 1.0e-8,
                "l_max_its": 200,
                "gmres_restart_interval": 50,
            },
        ],
        xs_map=[{"block_ids": [0], "xs": xs_crit}],
        boundary_conditions=[
            {"name": "xmin", "type": "reflecting"},
            {"name": "xmax", "type": "reflecting"},
            {"name": "ymin", "type": "reflecting"},
            {"name": "ymax", "type": "reflecting"},
            {"name": "zmin", "type": "reflecting"},
            {"name": "zmax", "type": "reflecting"},
        ],
        options={
            "use_precursors": True,
            "verbose_inner_iterations": False,
            "verbose_outer_iterations": False,
            "verbose_ags_iterations": False,
        },
        time_dependent=True,
    )

    solver = TransientKEigenSolver(problem=phys, max_iters=200, k_tol=1.0e-10)
    solver.Initialize()

    # Swap to supercritical XS at t=0
    phys.SetXSMap(xs_map=[{"block_ids": [0], "xs": xs_super}])

    # Semi-analytic parameters
    beta = 0.0065
    lam = 0.08
    k = 1.2
    rho = (k - 1.0) / k
    # Lambda based on infinite-medium definition (prompt gen time)
    nu_prompt = 1.987
    nu_delayed = 0.013
    sigma_f = 0.180000
    v = 1.0
    nu_sigma_f = sigma_f * (nu_prompt + nu_delayed)
    Lambda = 1.0 / (v * nu_sigma_f)

    dt = 1.0e-2
    solver.SetTimeStep(dt)
    solver.SetTheta(1.0)

    fr0 = phys.ComputeFissionProduction("new")

    t_end = 0.2
    rel_tol = 2.0e-2
    ok = True
    print("step time ratio_numeric ratio_analytic")
    step = 0
    while phys.GetTime() < t_end:
        step += 1
        solver.Step()
        fr_new = phys.ComputeFissionProduction("new")
        solver.Advance()
        t_to = phys.GetTime()

        ratio_num = fr_new / fr0
        ratio_ana = delayed_phi_ratio(t_to, beta, lam, rho, Lambda)

        print(f"{step:4d} {t_to:10.4e} {ratio_num:12.6e} {ratio_ana:12.6e}")
        if abs(ratio_num - ratio_ana) > rel_tol * ratio_ana:
            ok = False

    print(f"ANALYTIC_PASS {1 if ok else 0}")
