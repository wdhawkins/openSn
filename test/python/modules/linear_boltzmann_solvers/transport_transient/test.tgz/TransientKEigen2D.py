#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
TransientKEigen2D.lua -> OpenSn Python conversion
"""

import math
import os


def xs_path(name):
    return os.path.join(os.path.dirname(__file__), name)


# --- Mesh ---
N = 160
L = 80.96897163
xmin = -L / 2.0
dx = L / N
nodes = [xmin + i * dx for i in range(N + 1)]

meshgen = OrthogonalMeshGenerator(node_sets=[nodes, nodes])
grid = meshgen.Execute()
grid.SetUniformBlockID(0)

# central region block id = 1
vol0 = RPPLogicalVolume(xmin=-L/16, xmax=L/16,
                        ymin=-L/16, ymax=L/16,
                        zmin=-L/16, zmax=L/16)
grid.SetBlockIDFromLogicalVolume(vol0, 1, True)

# --- XS setup (microscopic -> combined with atom_density) ---
atom_density = 0.056559

xs_strong_micro = MultiGroupXS()
xs_strong_micro.LoadFromOpenSn(xs_path("xs_inf_k1_6_1g.cxs"))

xs_weakA_micro = MultiGroupXS()
xs_weakA_micro.LoadFromOpenSn(xs_path("xs_inf_critical_1g.cxs"))

xs_weakB_micro = MultiGroupXS()
xs_weakB_micro.LoadFromOpenSn(xs_path("xs_inf_weak2_1g.cxs"))

xs_strong = MultiGroupXS()
xs_strong.Combine([(xs_strong_micro, atom_density)])

xs_weakA = MultiGroupXS()
xs_weakA.Combine([(xs_weakA_micro, atom_density)])

xs_weakB = MultiGroupXS()
xs_weakB.Combine([(xs_weakB_micro, atom_density)])

num_groups = 1

# --- Quadrature ---
pquad = GLCProductQuadrature2DXY(n_polar=6, n_azimuthal=12, scattering_order=0)

# --- Physics ---
phys = DiscreteOrdinatesProblem(
    mesh=grid,
    num_groups=num_groups,
    groupsets=[
        {
            "groups_from_to": (0, num_groups - 1),
            "angular_quadrature": pquad,
            "inner_linear_method": "petsc_gmres",
            "l_abs_tol": 1.0e-6,
            "l_max_its": 1000,
            "gmres_restart_interval": 100,
        },
    ],
    xs_map=[
        {"block_ids": [1], "xs": xs_strong},  # strong fuel in center
        {"block_ids": [0], "xs": xs_weakA},   # weak fuel elsewhere
    ],
    boundary_conditions=[
        {"name": "xmin", "type": "reflecting"},
        {"name": "xmax", "type": "reflecting"},
        {"name": "ymin", "type": "reflecting"},
        {"name": "ymax", "type": "reflecting"},
    ],
    options={
        "use_precursors": True,
        "verbose_inner_iterations": False,
        "verbose_outer_iterations": False,
    },
    time_dependent=True,
)

solver = TransientKEigenSolver(problem=phys, max_iters=1000, k_tol=1.0e-8, verbose=False)
solver.Initialize()
solver.SetTimeStep(0.1)
solver.SetTheta(0.75)

initial_fr = phys.ComputeFissionProduction("old")

time_stop = 1.0
swapped = False
k = 0

while phys.GetTime() < time_stop:
    k += 1
    dt = phys.GetTimeStep()
    time_from = phys.GetTime()
    solver.Step()
    fr_new = phys.ComputeFissionProduction("new")
    fr_old = phys.ComputeFissionProduction("old")
    solver.Advance()
    time_to = phys.GetTime()

    ratio = fr_new / fr_old
    if ratio <= 0.0:
        period = float("inf")
    elif abs(ratio - 1.0) < 1.0e-12:
        period = float("inf")
    else:
        period = dt / math.log(ratio)

    if rank == 0:
        print(f"{k:4d} time={time_to:10.3g} (from={time_from:10.3g} dt={dt:10.4g}) "
              f"period={period:10.3g} FR={fr_new / initial_fr:10.3e}")

    if (time_to >= 0.2) and (not swapped):
        # swap weak fuel to weakB
        phys.SetXSMap(xs_map=[
            {"block_ids": [1], "xs": xs_strong},
            {"block_ids": [0], "xs": xs_weakB},
        ])
        swapped = True
