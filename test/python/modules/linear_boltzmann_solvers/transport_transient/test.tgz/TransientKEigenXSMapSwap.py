#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Transient k-eigenvalue XS swap test.

Analytic check: with fixed flux, total fission rate scales linearly with SIGMA_F.
We initialize on a critical XS, swap to a scaled XS via SetXSMap, and compare
FR_new / FR_old to SIGMA_F_scaled / SIGMA_F_crit.
"""

import os
import sys


if __name__ == "__main__":

    num_cells = 10
    length = 10.0
    dx = length / num_cells
    nodes = [i * dx for i in range(num_cells + 1)]
    meshgen = OrthogonalMeshGenerator(node_sets=[nodes])
    grid = meshgen.Execute()
    grid.SetUniformBlockID(0)

    num_groups = 1
    xs_crit = MultiGroupXS()
    xs_crit.LoadFromOpenSn("xs_swap_crit_1g.cxs")
    xs_scaled = MultiGroupXS()
    xs_scaled.LoadFromOpenSn("xs_swap_scaled_1g.cxs")

    # Quadrature
    pquad = GLProductQuadrature1DSlab(n_polar=4, scattering_order=0)

    # LBS problem (time dependent)
    phys = DiscreteOrdinatesProblem(
        mesh=grid,
        num_groups=num_groups,
        groupsets=[
            {
                "groups_from_to": (0, num_groups - 1),
                "angular_quadrature": pquad,
                "inner_linear_method": "classic_richardson",
                "l_abs_tol": 1.0e-8,
                "l_max_its": 200,
                "gmres_restart_interval": 50,
            },
        ],
        xs_map=[
            {
                "block_ids": [0],
                "xs": xs_crit
            }
        ],
        boundary_conditions=[
            {"name": "zmin", "type": "reflecting"},
            {"name": "zmax", "type": "reflecting"},
        ],
        options={
            "use_precursors": False,
            "verbose_inner_iterations": False,
            "verbose_outer_iterations": False,
            "verbose_ags_iterations": False,
        },
        time_dependent=True,
    )

    solver = TransientKEigenSolver(problem=phys)
    solver.Initialize()

    # Baseline fission rate with critical XS
    fr_old = phys.ComputeFissionRate("new")

    # Swap XS map mid-run
    phys.SetXSMap(xs_map=[{"block_ids": [0], "xs": xs_scaled}])

    # Fission rate with same flux, new XS
    fr_new = phys.ComputeFissionRate("new")

    ratio_actual = fr_new / fr_old
    ratio_expected = 0.180000 / 0.150000

    print(f"FR_RATIO_EXPECTED {ratio_expected:.12e}")
    print(f"FR_RATIO_ACTUAL {ratio_actual:.12e}")

    # Run transient steps to exercise time-dependent path with swapped XS
    solver.SetTimeStep(1.0e-3)
    solver.Execute()
